import gradio as gr
from ultralytics import YOLO
from PIL import Image
from huggingface_hub import hf_hub_download
import os

# --- Configuration ---
REPO_ID = "ITI121-25S2/2612796Q"
# Assuming your model file is named 'best.pt' inside the repo. 
# If it is 'best.onnx' or inside a folder, see the comments below.
MODEL_FILENAME = "best.pt" 

def load_model(repo_id, model_filename):
    print(f"Loading model from {repo_id}...")
    try:
        # Method 1: Download single .pt file (Most common)
        model_path = hf_hub_download(repo_id=repo_id, filename=model_filename)
        detection_model = YOLO(model_path)
        
        # Method 2: Use this ONLY if you uploaded a folder (like OpenVINO)
        # from huggingface_hub import snapshot_download
        # download_dir = snapshot_download(repo_id)
        # model_path = os.path.join(download_dir, "best_int8_openvino_model") # check your folder name!
        # detection_model = YOLO(model_path, task='detect')
        
        return detection_model
    except Exception as e:
        print(f"Error loading model: {e}")
        raise e

# Initialize model
detection_model = load_model(REPO_ID, MODEL_FILENAME)

def predict(pilimg, conf_threshold, iou_threshold):
    if pilimg is None:
        return None
        
    source = pilimg
    
    # Run prediction with adjustable thresholds
    result = detection_model.predict(
        source, 
        conf=conf_threshold, 
        iou=iou_threshold
    )
    
    # Plot results
    img_bgr = result[0].plot()
    out_pilimg = Image.fromarray(img_bgr[..., ::-1])  # Convert BGR to RGB
    
    return out_pilimg

# --- Gradio Interface ---
with gr.Blocks() as app:
    gr.Markdown("# Object Detection App")
    gr.Markdown(f"Running model from: huggingface.co/{REPO_ID}")
    
    with gr.Row():
        with gr.Column():
            input_image = gr.Image(type="pil", label="Input Image")
            
            # Sliders for tweaking model performance
            conf_slider = gr.Slider(
                minimum=0.0, maximum=1.0, value=0.5, step=0.05, label="Confidence Threshold"
            )
            iou_slider = gr.Slider(
                minimum=0.0, maximum=1.0, value=0.6, step=0.05, label="IOU Threshold"
            )
            
            submit_btn = gr.Button("Detect", variant="primary")
            
        with gr.Column():
            output_image = gr.Image(type="pil", label="Detection Result")

    submit_btn.click(
        fn=predict,
        inputs=[input_image, conf_slider, iou_slider],
        outputs=output_image
    )

if __name__ == "__main__":
    app.launch(share=True)