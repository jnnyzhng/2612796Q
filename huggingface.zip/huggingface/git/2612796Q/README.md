---
title: 2612796Q
emoji: 🍟 & 🍔
colorFrom: indigo
colorTo: red
python_version: 3.8
sdk: gradio
sdk_version: 4.0.2
app_file: app.py
pinned: false
license: apache-2.0
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
